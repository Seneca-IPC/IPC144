#!/bin/zsh

clear
echo "===================================================="
echo "         GIT PUSH UTILITY AUTO-INSTALLER              "
echo "===================================================="
echo ""

# [VALIDATION STEP] Check if Git is installed on macOS
if ! command -v git &> /dev/null; then
    echo "[ERROR] Git is NOT installed on this Mac."
    echo "         Please download and install Git from: https://git-scm.com"
    echo "         Alternatively, install Xcode Command Line Tools by running:"
    echo "         xcode-select --install"
    echo "         After installing Git, run this installer again."
    echo ""
    echo "Press Enter to exit..."
    read -r
    exit 1
fi

TARGET_DIR="$HOME/GitScripts"
SCRIPT_NAME="gitpush.sh" # Changed to .sh

SCRIPT_SOURCE_DIR="$(dirname "$0")"

echo "[1/3] Creating directory at $TARGET_DIR..."
if [ ! -d "$TARGET_DIR" ]; then
    mkdir -p "$TARGET_DIR"
fi

echo "[2/3] Deploying $SCRIPT_NAME..."
if [ -f "$SCRIPT_SOURCE_DIR/$SCRIPT_NAME" ]; then
    cp -f "$SCRIPT_SOURCE_DIR/$SCRIPT_NAME" "$TARGET_DIR/$SCRIPT_NAME"
    chmod +x "$TARGET_DIR/$SCRIPT_NAME"
    echo "       Successfully deployed script!"
else
    echo "[ERROR] Could not find $SCRIPT_NAME in this folder."
    echo "         Please ensure install.command and $SCRIPT_NAME are in the same folder."
    echo "Press Enter to exit..."
    read -r
    exit 1
fi

echo "[3/3] Registering folder in your Mac PATH..."

ZSH_RC="$HOME/.zshrc"
touch "$ZSH_RC"

if grep -q "GitScripts" "$ZSH_RC"; then
    echo "       Your PATH variable is already configured. Skipping update."
else
    echo "" >> "$ZSH_RC"
    echo "# Git Push Utility Shortcut" >> "$ZSH_RC"
    echo "export PATH=\"\$PATH:$TARGET_DIR\"" >> "$ZSH_RC"
    # The alias maps the easy command 'gitpush' directly to the .sh file
    echo "alias gitpush=\"$TARGET_DIR/$SCRIPT_NAME\"" >> "$ZSH_RC"
    echo "       Mac environment PATH updated successfully!"
fi

echo ""
echo "===================================================="
echo "  INSTALLATION COMPLETE! "
echo "  Please RESTART your Terminal application to use 'gitpush'."
echo "===================================================="
echo ""
echo "Press Enter to close this window..."
read -r
