#!/bin/zsh

# Note: Must be executed from within a GitHub cloned repository
# Usage:
# gitpush "Fixed the login layout bug"

# Check if the user passed a commit message argument
if [ -z "$1" ]; then
    echo "[ERROR] Please provide a commit message."
    echo "Usage: gitpush \"Your commit message here\""
    exit 1
fi

echo ""

# [BEHIND COMMIT CHECK] Verify if local branch is out of date
echo "[PRE-CHECK] Checking if remote repository has newer changes..."
git fetch origin &> /dev/null
if git status -uno | grep -q "your branch is behind"; then
    echo "[ERROR] Your branch is out of date with GitHub."
    echo "         Please run 'git pull' to grab latest changes before pushing."
    exit 1
fi
echo "           Branch status verified up-to-date!"
echo ""

echo "[1/3] Staging all changes..."
git add -A
if [ $? -ne 0 ]; then
    echo "[ERROR] Git add failed. Script stopped."
    exit 1
fi

echo "[2/3] Committing with your message..."
git commit -am "$1"
if [ $? -ne 0 ]; then
    echo "[ERROR] Git commit failed. Script stopped."
    exit 1
fi

echo "[3/3] Pushing to remote repository..."
git push origin main
if [ $? -ne 0 ]; then
    echo "[ERROR] Git push failed. Script stopped."
    exit 1
fi

echo "Success: Changes pushed to GitHub!"
