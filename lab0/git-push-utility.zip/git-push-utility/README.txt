============================================================
           GIT PUSH UTILITY SETUP INSTRUCTIONS
============================================================

This utility automates the process of adding, committing, 
and pushing your changes to GitHub with a single command.

IMPORTANT:
If this content is in a .ZIP archive file, you MUST EXTRACT
the contents first before proceeding!

------------------------------------------------------------
💻 FOR WINDOWS USERS
------------------------------------------------------------
1. Be sure the complete file contents is extracted from the .zip archive
2. Using file explorer, open the git-push-utility "Windows" sub-folder.
3. Double-click "install.bat".
4. Close the command window - it is now ready for use!
5. To use: Open a Command Prompt window, navigate to your git repo,
   and type:
   gitpush "Your commit message here"

------------------------------------------------------------
🍏 FOR MACOS USERS
------------------------------------------------------------
1. Be sure the complete file contents is extracted from the .zip archive
2. Open your Terminal app (Applications > Utilities > Terminal).
3. Type 'xattr -cr ' (with a space at the end) but DO NOT press enter yet.
4. Drag and drop this unzipped "git-push-utility" folder 
   from Finder directly into the Terminal window, then press Enter.
5. Open the "MacOS" folder in Finder and double-click "install.command".
6. Close your Terminal application window, - it is now ready for use!
7. To use: Open a Terminal window session, navigate to your git repo, and type:
   gitpush "Your commit message here"

============================================================
