============================================================
           GIT PUSH UTILITY SETUP INSTRUCTIONS
============================================================

This utility automates the process of adding, committing, 
and pushing your changes to GitHub with a single command.

IMPORTANT:
If this content is in a .ZIP archive file, you MUST EXTRACT
the contents first before proceeding!

------------------------------------------------------------
💻 FOR WINDOWS USERS
------------------------------------------------------------
1. Be sure the complete file contents is extracted from the .zip archive
     (right-click the zip file and select "Extract all...")
2. Using file explorer, open the git-push-utility "Windows" sub-folder.
3. Double-click "install.bat".
4. Close the command window - it is now ready for use!

FYI: To use the utility, from a Command Prompt window, navigate to your 
     git repository (using appropriate cd commands), and type: 
     gitpush "Your commit message here"

------------------------------------------------------------
🍏 FOR MACOS USERS
------------------------------------------------------------
1. Be sure the complete file contents is extracted from the .zip archive
2. Open your Terminal app (Applications > Utilities > Terminal).
3. Type (MAKE SURE YOU ADD A SPACE at the end): 
     xattr -cr          !!! DO NOT press enter yet !!!
4. Drag and drop the extracted unzipped "git-push-utility" folder 
   from the Finder directly into the Terminal window, then press Enter.
5. In your terminal window, change to the MacOS directory:
     cd ~/Downloads/git-push-utility/MacOS
6. Apply execution permissions to the installer, enter the following in your terminal:
     chmod 700 install.command
7. Execute the installer:
     ./install.command
8. Close your Terminal application window, - it is now ready for use!

FYI: To use the utility, from a Terminal window, navigate to your 
     git repository (using appropriate cd commands), and type: 
     gitpush "Your commit message here"

============================================================
