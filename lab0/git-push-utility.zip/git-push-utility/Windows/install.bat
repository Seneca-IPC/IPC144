@echo off
setlocal enabledelayedexpansion

echo ====================================================
echo         GIT PUSH UTILITY AUTO-INSTALLER              
echo ====================================================
echo.

:: [VALIDATION STEP] Check if Git is installed on Windows
where git >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Git is NOT installed on this computer.
    echo         Please download and install Git from: https://git-scm.com
    echo         After installing Git, run this setup script again.
    echo.
    pause
    exit /b 1
)

:: Check for administrative privileges
net session >nul 2>&1
if %errorLevel% == 0 (
    goto :run_commands
) else (
    goto :get_admin
)

:get_admin
    echo Requesting administrative privileges...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b

:run_commands
    :: Change the startup type to Automatic
    sc config ssh-agent start= auto

    :: Start the service immediately
    net start ssh-agent
    
    echo.
    echo SSH Agent has been successfully enabled and started!
    
:: 1. Define the safe installation directory under the User's profile
set "TARGET_DIR=%USERPROFILE%\GitScripts"
set "SCRIPT_NAME=gitpush.bat"

echo [1/3] Creating directory at %TARGET_DIR%...
if not exist "%TARGET_DIR%" (
    mkdir "%TARGET_DIR%"
)

:: 2. Safely copy the target script to the new home
echo [2/3] Deploying %SCRIPT_NAME%...
if exist "%~dp0%SCRIPT_NAME%" (
    copy /Y "%~dp0%SCRIPT_NAME%" "%TARGET_DIR%\%SCRIPT_NAME%" >nul
    echo       Successfully deployed script!
) else (
    echo [ERROR] Could not find %SCRIPT_NAME% in this folder.
    echo         Please ensure install.bat and %SCRIPT_NAME% are in the same folder.
    pause
    exit /b 1
)

:: 3. Register the PATH variable cleanly via Windows Registry queries to prevent truncation bugs
echo [3/3] Registering folder in your Windows PATH...

:: Fetch the existing USER path directly from the Registry (safest method)
set "CURRENT_USER_PATH="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "CURRENT_USER_PATH=%%B"

:: Check if our target path is already registered to prevent duplicates
echo !CURRENT_USER_PATH! | find /I "%TARGET_DIR%" >nul
if %errorlevel% equ 0 (
    echo       Your PATH variable is already configured. Skipping update.
) else (
    :: Append the new path safely using setx for future sessions
    if "%CURRENT_USER_PATH%"=="" (
        setx Path "%TARGET_DIR%" >nul
    ) else (
        setx Path "%CURRENT_USER_PATH%;%TARGET_DIR%" >nul
    )
    echo       Windows environment PATH updated successfully!
)

echo.
echo ====================================================
echo  INSTALLATION COMPLETE! 
echo  Please RESTART any open Command Prompts to use 'gitpush'.
echo ====================================================
echo.
pause
