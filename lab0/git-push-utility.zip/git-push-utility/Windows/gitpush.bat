:: Note: Must be in a folder that is a GitHub cloned repository
:: Usage:
:: gitpush.bat "Fixed the login layout bug"

@echo off
setlocal enabledelayedexpansion

:: Check if the user passed a commit message argument
if "%~1"=="" (
    echo [ERROR] Please provide a commit message.
    echo Usage: %~0 "Your commit message here"
    exit /b 1
)
echo.

:: [BEHIND COMMIT CHECK] Verify if local branch is out of date
echo [PRE-CHECK] Checking if remote repository has newer changes...
call git fetch origin >nul 2>nul
call git status -uno | find /I "your branch is behind" >nul
if %errorlevel% equ 0 (
    echo [ERROR] Your branch is out of date with GitHub.
    echo         Please run 'git pull' to grab latest changes before pushing.
    exit /b 1
)
echo            Branch status verified up-to-date!
echo.

echo [1/3] Staging all changes...
call git add -A
if %errorlevel% neq 0 goto error

echo [2/3] Committing with your message...
call git commit -am "%~1"
if %errorlevel% neq 0 goto error

echo [3/3] Pushing to remote repository...
call git push origin main
if %errorlevel% neq 0 goto error

echo Success: Changes pushed to GitHub!
exit /b 0

:error
echo [ERROR] Git operation failed. Script stopped.
exit /b %errorlevel%
